import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        lime: "#c8f645",
        "lime-deep": "#a8d42a",
        dark: "#0c0c0c",
        surface: "#141414",
      },
      fontFamily: {
        barlow: ["'Barlow Condensed'", "sans-serif"],
        dm: ["'DM Sans'", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
