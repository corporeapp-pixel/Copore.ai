# Corpore AI

Análise corporal com inteligência artificial.

## Setup

1. Clone o repositório
2. Instale as dependências: `npm install`
3. Copie o arquivo de ambiente: `cp .env.example .env.local`
4. Adicione sua chave da Anthropic no `.env.local`
5. Rode localmente: `npm run dev`

## Deploy no Vercel

1. Conecte o repositório no Vercel
2. Adicione a variável de ambiente `ANTHROPIC_API_KEY`
3. Deploy automático

## Variáveis de Ambiente

| Variável | Descrição |
|---|---|
| `ANTHROPIC_API_KEY` | Chave da API Anthropic |
